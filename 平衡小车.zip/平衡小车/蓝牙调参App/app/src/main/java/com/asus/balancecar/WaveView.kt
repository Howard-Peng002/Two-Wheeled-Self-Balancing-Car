package com.asus.balancecar

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil

/**
 * 车身角度实时波形。
 *
 * 只画一条曲线（Pitch），纵轴以 0 为中心自适应：取可见数据的最大绝对值，
 * 向上取整到 5 的倍数。这样直立环的振荡幅度一眼能看出来，
 * 不振荡时纵轴会自动收窄，抖动也会被放大显示。
 */
class WaveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val data = ArrayList<Float>(CAP)
    private val lock = Any()

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1f
        color = 0xFF1E2A36.toInt()
    }
    private val zeroPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1.5f
        color = 0xFF33475A.toInt()
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        color = 0xFF4FC3F7.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 22f
        color = 0xFF6B8299.toInt()
    }
    private val bgPaint = Paint().apply { color = 0xFF0E141B.toInt() }
    private val path = Path()

    /** 推入一个角度采样。可以从任意线程调用。 */
    fun push(v: Float) {
        synchronized(lock) {
            data.add(v)
            if (data.size > CAP) data.removeAt(0)
        }
        postInvalidateOnAnimation()
    }

    fun clear() {
        synchronized(lock) { data.clear() }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val snap: FloatArray
        synchronized(lock) { snap = FloatArray(data.size) { data[it] } }
        if (snap.size < 2) {
            canvas.drawText("等待数据…", 16f, h / 2, textPaint)
            return
        }

        // 纵轴自适应：0 居中，取最大绝对值向上取整到 5 的倍数
        var m = 5f
        for (v in snap) if (abs(v) > m) m = abs(v)
        m = ceil(m / 5f) * 5f

        val mid = h / 2f
        val scale = (h / 2f - 14f) / m

        // 横向网格（上中下三条）
        for (k in -1..1) {
            val y = mid - k * m * scale
            canvas.drawLine(0f, y, w, y, if (k == 0) zeroPaint else gridPaint)
        }

        // 曲线：最后一个点贴右边，向左铺开
        path.reset()
        val step = w / (CAP - 1).toFloat()
        val startX = w - (snap.size - 1) * step
        for (i in snap.indices) {
            val x = startX + i * step
            val y = mid - snap[i] * scale
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, linePaint)

        // 刻度
        canvas.drawText("%.0f°".format(m), 6f, 24f, textPaint)
        canvas.drawText("%.0f°".format(-m), 6f, h - 8f, textPaint)
    }

    private companion object {
        const val CAP = 320
    }
}
