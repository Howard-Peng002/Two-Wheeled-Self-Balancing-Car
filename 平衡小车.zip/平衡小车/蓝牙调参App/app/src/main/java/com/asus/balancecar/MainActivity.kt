package com.asus.balancecar

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.res.ColorStateList
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import java.util.ArrayDeque
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * 平衡小车蓝牙调参 App。
 *
 * 走经典蓝牙 SPP 连 HC-05/HC-06，和固件的文本协议对接：
 *   手机→小车  "vk=-340" / "f" / "s" （回车结尾）
 *   小车→手机  "角度,角速度,直立环,速度环,转向环,左PWM,右PWM" 的 CSV
 *
 * 参数改动只发一条命令，不用重新烧录。
 */
class MainActivity : AppCompatActivity() {

    private data class Param(
        val key: String,
        val label: String,
        val min: Double,
        val max: Double,
        val init: Double,
        val digits: Int
    )

    /** 量程对应固件 control.c 里的参考值：直立环 Kp 0~1000、Kd 0~10，速度环 Kp 0~1 */
    private val params = listOf(
        Param("vk", "直立环 Kp", -1000.0, 0.0, -400.0, 0),
        Param("vd", "直立环 Kd", -10.0, 0.0, -1.92, 2),
        Param("vp", "速度环 Kp", 0.0, 1.0, 0.6, 3),
        Param("vi", "速度环 Ki", 0.0, 0.05, 0.0022, 4),
        Param("td", "转向环 Kd", 0.0, 2.0, 0.6, 2),
        Param("tp", "转向环 Kp", 0.0, 100.0, 20.0, 0),
        Param("ma", "机械中值", -20.0, 20.0, -2.0, 1)
    )

    private val value = HashMap<String, Double>()
    private val bars = HashMap<String, SeekBar>()
    private val labels = HashMap<String, TextView>()

    private lateinit var wave: WaveView
    private lateinit var tvStatus: TextView
    private lateinit var tvPitch: TextView
    private lateinit var tvDistance: TextView
    private lateinit var sliderBox: LinearLayout
    private var selectedMode = 0 // 0=关，1=蓝牙控制，2=自动模式
    private var distanceText = "--"
    private var modeState = "stopped"
    private var manualHazard = false
    private var driveText = ""
    @Volatile private var lastStopAckAt = 0L

    @Volatile
    private var socket: BluetoothSocket? = null

    @Volatile
    private var out: OutputStream? = null

    @Volatile
    private var connected = false

    @Volatile
    private var lastRxAt = 0L

    @Volatile private var bleGatt: BluetoothGatt? = null
    @Volatile private var bleWrite: BluetoothGattCharacteristic? = null
    private val bleQueue = ArrayDeque<ByteArray>()
    private var bleWriting = false
    private var bleWriteStartedAt = 0L
    private var stopRequestId = 0
    private val lineBuffer = StringBuilder()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val tx = Executors.newSingleThreadExecutor()
    private var lastLiveSend = 0L
    private var lastUiUpdate = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wave = findViewById(R.id.wave)
        tvStatus = findViewById(R.id.tvStatus)
        tvPitch = findViewById(R.id.tvPitch)
        tvDistance = findViewById(R.id.tvDistance)
        sliderBox = findViewById(R.id.sliderBox)

        buildSliders()

        findViewById<Button>(R.id.btnConnect).setOnClickListener {
            if (ensurePermissions()) pickDevice()
        }
        // Tap once to keep moving; only Stop cancels motion, matching the user's control workflow.
        findViewById<Button>(R.id.btnFwd).setOnClickListener { if (selectedMode == 1) { stopRequestId++; sendByte(0x01) } }
        findViewById<Button>(R.id.btnBack).setOnClickListener { if (selectedMode == 1) { stopRequestId++; sendByte(0x05) } }
        findViewById<Button>(R.id.btnLeft).setOnClickListener { if (selectedMode == 1) { stopRequestId++; sendByte(0x07) } }
        findViewById<Button>(R.id.btnRight).setOnClickListener { if (selectedMode == 1) { stopRequestId++; sendByte(0x03) } }
        findViewById<Button>(R.id.btnStop).setOnClickListener { emergencyStop() }
        findViewById<Button>(R.id.btnManual).setOnClickListener {
            setMode(if (selectedMode == 1) "mode=off" else "mode=manual")
        }
        findViewById<Button>(R.id.btnAuto).setOnClickListener {
            setMode(if (selectedMode == 2) "mode=off" else "mode=auto")
        }
        updateModeUi()

        if (ensurePermissions()) {
            val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            val saved = getSharedPreferences("bluetooth", MODE_PRIVATE).getString("last_ble_address", null)
            if (saved != null) connectBle(adapter.getRemoteDevice(saved))
            else scanBle(adapter, autoConnect = true)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnect()
        tx.shutdown()
    }

    // ---------------- 蓝牙 ----------------

    private fun ensurePermissions(): Boolean {
        val need = ArrayList<String>()
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        for (p in permissions) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        if (need.isEmpty()) return true
        ActivityCompat.requestPermissions(this, need.toTypedArray(), REQ_BT)
        return false
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_BT) return
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            pickDevice()
        } else {
            toast("没给蓝牙权限，连不上模块")
        }
    }

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        val adapter: BluetoothAdapter? =
            (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null) {
            toast("这台手机没有蓝牙")
            return
        }
        if (!adapter.isEnabled) {
            toast("请先在系统设置里打开蓝牙")
            return
        }

        val paired = try {
            adapter.bondedDevices.toList()
        } catch (e: SecurityException) {
            emptyList()
        }
        val serialPaired = paired.filterNot {
            (it.name ?: "").uppercase(Locale.US).contains("JDY-69A-AU")
        }
        val items = arrayOf("扫描 BLE 串口（JDY-69A-BL，推荐）") +
            serialPaired.map { "经典蓝牙 SPP：${it.name ?: "未知设备"}\n${it.address}" }
        AlertDialog.Builder(this)
            .setTitle("选择蓝牙模块")
            .setItems(items) { _, i -> if (i == 0) scanBle(adapter) else connect(serialPaired[i - 1]) }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun scanBle(adapter: BluetoothAdapter, autoConnect: Boolean = false) {
        val scanner = adapter.bluetoothLeScanner ?: run { status("BLE 扫描不可用"); return }
        val found = LinkedHashMap<String, BluetoothDevice>()
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.scanRecord?.deviceName ?: result.device.name ?: ""
                if (name.contains("JDY", ignoreCase = true)) found[result.device.address] = result.device
            }
            override fun onScanFailed(errorCode: Int) {
                runOnUiThread { status("BLE 扫描失败：$errorCode") }
            }
        }
        status("扫描 JDY 蓝牙串口中…")
        try { scanner.startScan(callback) } catch (e: Exception) {
            status("BLE 扫描失败：${e.message}"); return
        }
        mainHandler.postDelayed({
            try { scanner.stopScan(callback) } catch (_: Exception) {}
            if (found.isEmpty()) { status("未找到 JDY-BL；确认模块已上电并允许附近设备权限"); return@postDelayed }
            val devices = found.values.toList()
            val carModules = devices.filter { (it.name ?: "").contains("JDY-69A-BL", ignoreCase = true) }
            if (autoConnect && carModules.size == 1) { connectBle(carModules.first()); return@postDelayed }
            val labels = devices.map { "${it.name ?: "JDY-BL"}\n${it.address}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("选择 BLE 串口（优先选 JDY-69A-BL）")
                .setItems(labels) { _, i -> connectBle(devices[i]) }.show()
        }, 5000)
    }

    @SuppressLint("MissingPermission")
    private fun connectBle(dev: BluetoothDevice) {
        disconnect()
        status("正在连接 BLE：${dev.name ?: dev.address} …")
        try { bleGatt = dev.connectGatt(this, false, bleCallback) }
        catch (e: Exception) { status("BLE 连接失败：${e.message}") }
    }

    private val bleCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (gatt !== bleGatt) return
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                if (!gatt.discoverServices()) runOnUiThread { status("BLE 服务发现失败") }
            } else {
                connected = false
                bleWrite = null
                bleGatt = null
                gatt.close()
                runOnUiThread { status("BLE 已断开（状态 $status）") }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (gatt !== bleGatt) return
            val ch = if (status == BluetoothGatt.GATT_SUCCESS)
                gatt.getService(BLE_SERVICE)?.getCharacteristic(BLE_CHAR) else null
            if (ch == null) { runOnUiThread { status("模块没有 FFE0/FFE1 串口服务") }; return }
            bleWrite = ch
            if (!gatt.setCharacteristicNotification(ch, true)) {
                runOnUiThread { status("BLE 数据通知启用失败") }; return
            }
            val descriptor = ch.getDescriptor(BLE_CCCD)
            if (descriptor == null) { bleReady(gatt); return }
            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (!gatt.writeDescriptor(descriptor)) runOnUiThread { status("BLE 通知订阅失败") }
        }

        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (gatt !== bleGatt) return
            if (status == BluetoothGatt.GATT_SUCCESS) bleReady(gatt)
            else runOnUiThread { status("BLE 通知订阅失败：$status") }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (gatt === bleGatt) consumeReceived(characteristic.value)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (gatt === bleGatt) consumeReceived(value)
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (gatt !== bleGatt) return
            synchronized(bleQueue) { bleWriting = false }
            if (status != BluetoothGatt.GATT_SUCCESS) runOnUiThread { status("BLE 发送失败：$status") }
            writeNextBle()
        }
    }

    private fun bleReady(gatt: BluetoothGatt) {
        if (gatt !== bleGatt) return
        connected = true
        lastRxAt = System.currentTimeMillis()
        getSharedPreferences("bluetooth", MODE_PRIVATE).edit()
            .putString("last_ble_address", gatt.device.address).apply()
        runOnUiThread { status("BLE 串口已连接；等待小车数据") }
        send("ping")
        mainHandler.postDelayed({ if (bleGatt === gatt) send("show") }, 700)
        mainHandler.postDelayed({ if (bleGatt === gatt) send("mode?") }, 1000)
        thread {
            var lastProbeAt = System.currentTimeMillis()
            while (connected && bleGatt === gatt) {
                Thread.sleep(1000)
                if (bleGatt !== gatt) break
                val now = System.currentTimeMillis()
                if (now - lastProbeAt >= 2000) { send("ping"); lastProbeAt = now }
                if (now - lastRxAt > 5000) runOnUiThread {
                    if (bleGatt === gatt) status("BLE已连接，但5秒无串口回传；查看OLED的BT RX")
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun writeNextBle() {
        val gatt = bleGatt ?: return
        val ch = bleWrite ?: return
        val data: ByteArray
        synchronized(bleQueue) {
            if (bleWriting || bleQueue.isEmpty()) return
            data = bleQueue.removeFirst()
            bleWriting = true
            bleWriteStartedAt = System.currentTimeMillis()
        }
        val writeType = if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        ch.writeType = writeType
        ch.value = data
        if (!gatt.writeCharacteristic(ch)) {
            synchronized(bleQueue) { bleWriting = false }
            runOnUiThread { status("BLE 写入未提交，请重新连接") }
        }
    }

    @SuppressLint("MissingPermission")
    private fun connect(dev: BluetoothDevice) {
        disconnect()
        status("正在连接 ${dev.name} …")
        thread {
            val s = try {
                dev.createRfcommSocketToServiceRecord(SPP_UUID).also { it.connect() }
            } catch (e: Exception) {
                runOnUiThread { status("连接失败：${e.message}\n模块上电了吗？是不是被别的 App 占着？") }
                return@thread
            }
            socket = s
            out = try {
                s.outputStream
            } catch (e: IOException) {
                null
            }
            connected = true
            lastRxAt = System.currentTimeMillis()
            runOnUiThread { status("已连接：${dev.name}") }
            // RFCOMM连接成功只代表蓝牙链路建立；主动读取参数以验证MCU串口收发和命令解析。
            send("show")
            send("ping")
            send("mode?")
            // A remote module can drop RFCOMM while InputStream.read() remains blocked.
            // Poll the socket so the UI cannot keep claiming "connected" forever.
            thread {
                var noDataReported = false
                var lastProbeAt = System.currentTimeMillis()
                while (connected && socket === s) {
                    try {
                        Thread.sleep(1000)
                    } catch (_: InterruptedException) {
                        break
                    }
                    if (socket !== s) break
                    if (!s.isConnected) {
                        try { s.close() } catch (_: IOException) {}
                        connected = false
                        out = null
                        socket = null
                        runOnUiThread { status("蓝牙模块已断开，请重新连接") }
                        break
                    }
                    val now = System.currentTimeMillis()
                    if (now - lastProbeAt >= 2000) {
                        send("ping")
                        lastProbeAt = now
                    }
                    if (!noDataReported && now - lastRxAt > 5000) {
                        noDataReported = true
                        runOnUiThread {
                            if (socket === s) status("已发送ping，但5秒无串口回传；查看小车OLED的BT RX是否每2秒增加6")
                        }
                    }
                }
            }
            readLoop(s)
        }
    }

    private fun disconnect() {
        connected = false
        out = null
        try {
            socket?.close()
        } catch (e: IOException) {
            // 关不掉就算了，反正要丢掉引用
        }
        socket = null
        bleWrite = null
        val oldGatt = bleGatt
        bleGatt = null
        synchronized(bleQueue) { bleQueue.clear(); bleWriting = false }
        try { oldGatt?.disconnect(); oldGatt?.close() } catch (_: Exception) {}
    }

    private fun readLoop(s: BluetoothSocket) {
        val input: InputStream = try {
            s.inputStream
        } catch (e: IOException) {
            return
        }
        val buf = ByteArray(1024)
        while (connected && socket === s) {
            val n = try {
                input.read(buf)
            } catch (e: IOException) {
                -1
            }
            if (n < 0) break
            consumeReceived(buf.copyOf(n))
        }
        if (socket === s) {
            connected = false
            out = null
            socket = null
            runOnUiThread { status("蓝牙模块已断开，请重新连接") }
        }
    }

    @Synchronized private fun consumeReceived(data: ByteArray) {
        lastRxAt = System.currentTimeMillis()
        for (b in data) {
            val c = (b.toInt() and 0xFF).toChar()
            if (c == '\n' || c == '\r') {
                if (lineBuffer.isNotEmpty()) {
                    onLine(lineBuffer.toString())
                    lineBuffer.setLength(0)
                }
            } else if (lineBuffer.length < 256) lineBuffer.append(c)
        }
    }

    /** 收到一行。CSV 是数据，'#' 开头的是固件回执。 */
    private fun onLine(line: String) {
        if (line.startsWith("#dist=")) {
            distanceText = line.removePrefix("#dist=")
            runOnUiThread { updateModeUi() }
            return
        }
        if (line.startsWith("#mode=")) {
            selectedMode = when {
                line.startsWith("#mode=auto") -> 2
                line.startsWith("#mode=manual") -> 1
                else -> 0
            }
            modeState = line.substringAfter("state=", "stopped").substringBefore(' ')
            manualHazard = line.substringAfter(" mh=", "0").substringBefore(' ') == "1"
            val target = line.substringAfter(" t=", "").substringBefore(' ')
            val encoder = line.substringAfter(" e=", "").substringBefore(' ')
            driveText = if (target.isNotEmpty() && encoder.isNotEmpty()) " | 目标 $target 轮速 $encoder" else ""
            runOnUiThread {
                updateModeUi()
                if (System.currentTimeMillis() - lastStopAckAt > 2000) status(line)
            }
            return
        }
        if (line == "#cmd=s") {
            lastStopAckAt = System.currentTimeMillis()
            runOnUiThread { status("小车已确认停止命令") }
            return
        }
        if (line.startsWith("#err") || line.startsWith("#vk=")) android.util.Log.d("BalanceCar", line)
        if (line.startsWith("#vk=")) {
            val received = line.removePrefix("#").split(' ').mapNotNull { token ->
                val parts = token.split('=', limit = 2)
                if (parts.size == 2) parts[1].toDoubleOrNull()?.let { parts[0] to it } else null
            }
            runOnUiThread {
                for ((key, v) in received) {
                    val p = params.firstOrNull { it.key == key } ?: continue
                    value[key] = v
                    labels[key]?.text = fmt(p, v)
                    bars[key]?.progress = toProgress(p, v)
                }
                status("参数已从小车同步")
            }
            return
        }
        if (line.startsWith("#")) {
            runOnUiThread { if (System.currentTimeMillis() - lastStopAckAt > 2000) status(line) }
            return
        }
        val p = line.split(',')
        if (p.size < 2) return
        val pitch = p[0].trim().toFloatOrNull() ?: return
        val gyro = p[1].trim().toFloatOrNull() ?: return

        wave.push(pitch)

        val now = System.currentTimeMillis()
        if (now - lastUiUpdate < 100) return
        lastUiUpdate = now
        runOnUiThread {
            tvPitch.text = String.format(Locale.US, "角度 %.1f°    角速度 %d", pitch, gyro.toInt())
        }
    }

    /** 发一条命令，自动补回车。写串口会阻塞，所以丢到单独线程里排队。 */
    private fun send(cmd: String) {
        if (bleGatt != null && connected) {
            synchronized(bleQueue) { bleQueue.addLast((cmd + "\r\n").toByteArray(Charsets.US_ASCII)) }
            writeNextBle()
            return
        }
        val o = out
        if (o == null) {
            toast("还没连接蓝牙")
            return
        }
        tx.execute {
            try {
                o.write((cmd + "\r\n").toByteArray(Charsets.US_ASCII))
                o.flush()
            } catch (e: IOException) {
                runOnUiThread { status("发送失败，可能已断开") }
            }
        }
    }

    /** Send one raw byte, as the original APP does with HEX mode enabled. */
    private fun sendByte(value: Int) {
        if (bleGatt != null && connected) {
            synchronized(bleQueue) { bleQueue.addLast(byteArrayOf(value.toByte())) }
            writeNextBle()
            return
        }
        val o = out
        if (o == null) {
            toast("还没连接蓝牙")
            return
        }
        tx.execute {
            try {
                o.write(byteArrayOf(value.toByte()))
                o.flush()
            } catch (e: IOException) {
                runOnUiThread { status("发送失败，可能已断开") }
            }
        }
    }

    /** Stop is one BLE write: raw 0 stops in the UART ISR, text s provides an acknowledgement. */
    private fun emergencyStop() {
        if (bleGatt != null && connected) {
            val requestId = ++stopRequestId
            val requestedAt = System.currentTimeMillis()
            queueBleStop()
            mainHandler.postDelayed({ retryBleStop(requestId, requestedAt, false) }, 450)
            mainHandler.postDelayed({ retryBleStop(requestId, requestedAt, true) }, 1100)
            status("停止已发送，等待小车确认")
            return
        }
        sendByte(0x00)
        send("s")
        status("停止已发送，等待小车确认")
    }

    private fun queueBleStop() {
        synchronized(bleQueue) {
            bleQueue.clear()
            // A lost GATT callback must not block the safety command forever.
            if (bleWriting && System.currentTimeMillis() - bleWriteStartedAt > 400) bleWriting = false
            bleQueue.addFirst(byteArrayOf(0x00, 's'.code.toByte(), '\r'.code.toByte(), '\n'.code.toByte()))
        }
        writeNextBle()
    }

    private fun retryBleStop(requestId: Int, requestedAt: Long, finalRetry: Boolean) {
        if (requestId != stopRequestId || bleGatt == null || !connected || lastStopAckAt >= requestedAt) return
        queueBleStop()
        if (finalRetry) mainHandler.postDelayed({
            if (requestId == stopRequestId && lastStopAckAt < requestedAt)
                status("未收到停止回执；请扶住小车并切断电机电源")
        }, 700)
    }

    private fun setMode(cmd: String) {
        stopRequestId++
        if (bleGatt != null && connected) {
            synchronized(bleQueue) {
                bleQueue.clear()
                bleQueue.addLast(byteArrayOf(0x00))
                bleQueue.addLast((cmd + "\r\n").toByteArray(Charsets.US_ASCII))
            }
            writeNextBle()
            return
        }
        sendByte(0x00)
        send(cmd)
    }

    // ---------------- 遥控 ----------------

    private fun updateModeUi() {
        val modeName = when (selectedMode) {
            1 -> if (manualHazard) "蓝牙控制·前进禁行" else "蓝牙控制"
            2 -> "自动 $modeState"
            else -> "已关闭"
        }
        tvDistance.text = "前方距离 ${if (distanceText == "NA") "无效" else "$distanceText cm"}  |  $modeName$driveText"
        findViewById<Button>(R.id.btnManual).backgroundTintList =
            ColorStateList.valueOf(if (selectedMode == 1) 0xFF29B6F6.toInt() else 0xFF37474F.toInt())
        findViewById<Button>(R.id.btnAuto).backgroundTintList =
            ColorStateList.valueOf(if (selectedMode == 2) 0xFF29B6F6.toInt() else 0xFF37474F.toInt())
        for (id in intArrayOf(R.id.btnFwd, R.id.btnBack, R.id.btnLeft, R.id.btnRight))
            findViewById<Button>(id).isEnabled = selectedMode == 1
    }

    // ---------------- 滑块 ----------------

    private fun buildSliders() {
        for (p in params) {
            value[p.key] = p.init

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }

            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val name = TextView(this).apply {
                text = p.label
                setTextColor(0xFFB8C4D0.toInt())
                textSize = 13f
            }
            val shown = TextView(this).apply {
                text = fmt(p, p.init)
                setTextColor(0xFF4FC3F7.toInt())
                textSize = 15f
                gravity = Gravity.END
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener { askValue(p) }
            }
            head.addView(name, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            head.addView(shown, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            row.addView(head)

            val bar = SeekBar(this).apply {
                max = STEPS
                progress = toProgress(p, p.init)
            }
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, prog: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = fromProgress(p, prog)
                    value[p.key] = v
                    shown.text = fmt(p, v)
                    // 拖动中限流，不然一秒能刷出几百条命令把蓝牙带宽占满
                    val now = System.currentTimeMillis()
                    if (now - lastLiveSend >= LIVE_MS) {
                        lastLiveSend = now
                        send(cmdOf(p, v))
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}

                override fun onStopTrackingTouch(sb: SeekBar) {
                    send(cmdOf(p, value[p.key] ?: p.init)) // 松手必发一次，保证落在最终值上
                }
            })
            row.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

            sliderBox.addView(row)
            bars[p.key] = bar
            labels[p.key] = shown
        }
    }

    /** 点数值可以手输精确值。 */
    private fun askValue(p: Param) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or
                InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(fmt(p, value[p.key] ?: p.init))
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("${p.label}    量程 ${fmt(p, p.min)} ~ ${fmt(p, p.max)}")
            .setView(et)
            .setPositiveButton("确定") { _, _ ->
                val v = et.text.toString().trim().toDoubleOrNull()
                if (v == null) {
                    toast("这不是个数字")
                    return@setPositiveButton
                }
                val c = v.coerceIn(p.min, p.max)
                if (c != v) toast("超量程，已夹到 ${fmt(p, c)}")
                value[p.key] = c
                labels[p.key]?.text = fmt(p, c)
                bars[p.key]?.progress = toProgress(p, c)
                send(cmdOf(p, c))
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun toProgress(p: Param, v: Double): Int =
        (((v - p.min) / (p.max - p.min)) * STEPS).toInt().coerceIn(0, STEPS)

    private fun fromProgress(p: Param, prog: Int): Double =
        p.min + (p.max - p.min) * prog / STEPS

    // 必须锁 Locale.US，某些区域设置小数点是逗号，会把固件的 atof 喂坏
    private fun fmt(p: Param, v: Double): String = String.format(Locale.US, "%.${p.digits}f", v)

    private fun cmdOf(p: Param, v: Double) = "${p.key}=${fmt(p, v)}"

    // ---------------- 杂项 ----------------

    private fun status(s: String) {
        tvStatus.text = s
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        val BLE_SERVICE: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
        val BLE_CHAR: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")
        val BLE_CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        const val REQ_BT = 1001
        const val STEPS = 1000
        const val LIVE_MS = 150L
    }
}
