#include "stm32f10x.h"
#include "sys.h" 
#include "control.h"
#define TRIG PAout(3) //输出端口
#define ECHO PAin(2)  //输入端口
int length;
volatile u16 Sonar_Distance_Cm=0;
volatile u16 Sonar_Raw_Cm=0;
volatile u8 Sonar_Valid=0,Sonar_Sample_Seq=0;
static volatile u8 sonar_phase=0;
static volatile u16 sonar_rise=0;
static u16 sonar_trigger=0;
static u8 sonar_filtered_seq=0,sonar_display_ready=0,sonar_far_count=0;
static u16 sonar_far_candidate=0;

float Pitch,Roll,Yaw;						//角度
short gyrox,gyroy,gyroz;				//陀螺仪--角速度
short aacx,aacy,aacz;						//加速度
int Encoder_Left,Encoder_Right;	//编码器数据（速度）

int PWM_MAX=7200,PWM_MIN=-7200;	//PWM限幅变量
int MOTO1,MOTO2;								//电机装载变量

extern int Vertical_out,Velocity_out,Turn_out;
extern volatile int Encoder_Diag_Left,Encoder_Diag_Right;

/*串口调试开关：1=蓝牙遥测；超声波始终测距*/
/*数据从蓝牙口(USART3,PB10)发出，波特率见BT_BOUND*/
#define DEBUG_SERIAL  1

/*蓝牙波特率：必须和蓝牙模块内部波特率一致，改这里要同时改模块*/
/*模块出厂多是9600，用AT命令改；改不动就把这里改回9600重新烧录*/
#define BT_BOUND  9600

#if DEBUG_SERIAL
extern float dbg_Pitch, dbg_Gyroy;
extern int   dbg_Vertical_out, dbg_Velocity_out, dbg_Turn_out;
extern int   dbg_MOTO1, dbg_MOTO2;
extern volatile u8 dbg_ready;

/*Use integer formatting for telemetry so the plot still works when the Keil
  printf library was linked without floating-point format support.*/
static void BT_SendDebugCsv(void)
{
	int pitch100, gyro10;
	int pitchAbs, gyroAbs;

	pitch100=(int)(dbg_Pitch*100.0f);
	gyro10=(int)(dbg_Gyroy*10.0f);
	pitchAbs=(pitch100<0)?-pitch100:pitch100;
	gyroAbs=(gyro10<0)?-gyro10:gyro10;
	printf("%s%d.%02d,%s%d.%d,%d,%d,%d,%d,%d\r\n",
	       (pitch100<0)?"-":"",pitchAbs/100,pitchAbs%100,
	       (gyro10<0)?"-":"",gyroAbs/10,gyroAbs%10,
	       dbg_Vertical_out,dbg_Velocity_out,dbg_Turn_out,
	       dbg_MOTO1,dbg_MOTO2);
}
#endif
void Sonar_Init(void)
{
		GPIO_InitTypeDef GPIO_InitStruct;
		TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
		EXTI_InitTypeDef EXTI_InitStructure;
		NVIC_InitTypeDef NVIC_InitStructure;

		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); //时钟使能
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
			
		
		GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;//设置为推挽输出
		GPIO_InitStruct.GPIO_Pin=GPIO_Pin_3;
		GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&GPIO_InitStruct);
		TRIG=0;

		GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;
		GPIO_InitStruct.GPIO_Pin=GPIO_Pin_2;
		GPIO_Init(GPIOA,&GPIO_InitStruct);
	
		//定时器3初始化
		TIM_TimeBaseStructure.TIM_Period = 65535; // 10us/tick, 655ms wrap
		TIM_TimeBaseStructure.TIM_Prescaler =719;
		TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
		TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //向上计数模式
		TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

//		TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE );//使能制定TIM3中断，允许更新中断
//		//中断设置
//		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
//		NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
//		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
//		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//		NVIC_Init(&NVIC_InitStructure);

		TIM_Cmd(TIM3, ENABLE);
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource2);
		EXTI_InitStructure.EXTI_Line=EXTI_Line2;
		EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
		EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Rising_Falling;
		EXTI_InitStructure.EXTI_LineCmd=ENABLE;
		EXTI_Init(&EXTI_InitStructure);
		NVIC_InitStructure.NVIC_IRQChannel=EXTI2_IRQn;
		/* ECHO may be only a few hundred us wide. Timestamp edges before the
		   slower MPU/DMP balance ISR (priority 1) can delay them by milliseconds. */
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
		NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
		NVIC_Init(&NVIC_InitStructure);
}
//测距函数
void EXTI2_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line2)!=RESET)
	{
		u16 now=(u16)TIM3->CNT;
		if(sonar_phase==1 && ECHO){sonar_rise=now;sonar_phase=2;}
		else if(sonar_phase==2 && !ECHO)
		{
			u16 ticks=(u16)(now-sonar_rise);
			u16 cm=(u16)(((u32)ticks*10U)/58U);
			Sonar_Valid=(cm>=2 && cm<=400 && ticks<3000);
			if(Sonar_Valid)Sonar_Raw_Cm=cm;
			sonar_phase=0;
			Sonar_Sample_Seq++;
		}
		EXTI_ClearITPendingBit(EXTI_Line2);
	}
}

static void Sonar_Task(void)
{
	u16 now=(u16)TIM3->CNT;
	u16 raw;
	u8 seq;
	u8 valid;
	__disable_irq();
	if(sonar_phase && (u16)(now-sonar_trigger)>3000)
	{
		sonar_phase=0;
		Sonar_Valid=0;
		Sonar_Sample_Seq++;
	}
	seq=Sonar_Sample_Seq;
	valid=Sonar_Valid;
	raw=Sonar_Raw_Cm;
	__enable_irq();
	if(seq!=sonar_filtered_seq)
	{
		sonar_filtered_seq=seq;
		if(valid)
		{
			/* A single delayed/secondary far echo must not make a nearby wall
			   look clear. Confirm large increases before publishing them. */
			if(sonar_display_ready && raw>Sonar_Distance_Cm+20)
			{
				u16 diff=raw>sonar_far_candidate?raw-sonar_far_candidate:sonar_far_candidate-raw;
				if(sonar_far_count && diff<=15)sonar_far_count++;
				else sonar_far_candidate=raw,sonar_far_count=1;
				if(sonar_far_count>=2)
				{
					Sonar_Distance_Cm=raw;
					sonar_far_count=0;
				}
			}
			else
			{
				Sonar_Distance_Cm=raw;
				sonar_display_ready=1;
				sonar_far_count=0;
			}
		}
		else sonar_far_count=0;
	}
	/* TIM3 is 10us/tick: 75ms in manual mode, 100ms otherwise.
	   HC-SR04 documentation recommends a trigger interval over 60ms. */
	if(sonar_phase==0 && (u16)(now-sonar_trigger)>=(Nav_Mode==0?7500:10000))
	{
		sonar_trigger=now;
		sonar_phase=1;
		TRIG=1;
		delay_us(12);
		TRIG=0;
	}
}

/*往USART1(PA9)发一串，自检用：看蓝牙模块是不是接在这路上*/
static void USART1_Send_String(char *s)
{
	while(*s)
	{
		while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);
		USART_SendData(USART1,(u8)*s++);
	}
}

int main(void)
{
	u16 hb_cnt=0;//心跳分频
	u8 diag_div=0;//蓝牙诊断输出分频，避免刷屏
	u8 telemetry_div=0;//DMP约100Hz；9600波特串口只发约10行/秒
	char cmd_copy[CMD_MAX];
	u32 bt_tx_rows=0, oled_rx_seen=0, oled_tx_bucket=0;
	u8 oled_cmd_seen=0;
	delay_init();
	NVIC_Config();
	uart1_init(9600);	//自检：改成9600，和蓝牙模块一致才能看出东西

	uart3_init(BT_BOUND);//蓝牙，波特率要和模块一致

	OLED_Init();
	OLED_Clear();
	#if DEBUG_SERIAL
	OLED_ShowString(0,0,"BT RX:",12);
	OLED_ShowNumber(42,0,Bt_Rx,6,12);
	OLED_ShowString(0,2,"BT TX:",12);
	OLED_ShowNumber(42,2,0,6,12);
	OLED_ShowString(0,4,"LAST:",12);
	OLED_ShowNumber(42,4,Bt_Last,3,12);
	OLED_ShowString(0,6,"CMD:",12);
	OLED_ShowNumber(42,6,Bt_RawCmd,3,12);
	#else
	OLED_ShowString(0,3,"jiao du:",12);
	OLED_ShowString(0,4,"ju li:",12);
	OLED_ShowString(0,5,"sd:",12);
	#endif
	
	MPU_Init();
	mpu_dmp_init();
	MPU6050_EXTI_Init();
	
	Encoder_TIM2_Init();
	Encoder_TIM4_Init();
	Motor_Init();
	PWM_Init_TIM1(0,7199);
	
	Sonar_Init();
  while(1)
	{
		Sonar_Task();
		Navigation_Task();
		/*蓝牙自检：App调试模式下只发一次，避免高速主循环把串口占满*/
#if DEBUG_SERIAL
		if(hb_cnt<3 && ++hb_cnt>=3)
#else
		if(++hb_cnt>=3)
#endif
		{
#if !DEBUG_SERIAL
			hb_cnt=0;
#endif
			printf("#b3 %d\r\n",BT_BOUND);		//USART3，PB10
			USART1_Send_String("#b1 9600\r\n");	//USART1，PA9
		}

		if(Cmd_Ready)//收到一行蓝牙命令
		{
			USART_ITConfig(USART3,USART_IT_RXNE,DISABLE);//抄的时候别让中断改缓冲
			strcpy(cmd_copy,Cmd_Line);
			Cmd_Ready=0;
			USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
			BT_Cmd(cmd_copy);//解析放主循环，中断里只收字节
		}

		if(Bin_Ready)//收到一包蓝牙调试器的数据
		{
			USART_ITConfig(USART3,USART_IT_RXNE,DISABLE);//抄的时候别让中断改缓冲
			Bin_Ready=0;
			memcpy(Bin_Line,Bin_Buf,BIN_MAX);
			USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
			Bin_Apply();//解包写参数，校验没过就原样不动
		}

		if(Bt_RawCmd_Ready)//HEX遥控命令由主循环回执，避免在中断里printf
		{
			u8 raw_cmd;
			USART_ITConfig(USART3,USART_IT_RXNE,DISABLE);
			raw_cmd=Bt_RawCmd;
			Bt_RawCmd_Ready=0;
			USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
			if(raw_cmd==0x00)printf("#cmd=s\r\n");
			else if(raw_cmd==0x01)printf("#cmd=f\r\n");
			else if(raw_cmd==0x03)printf("#cmd=r\r\n");
			else if(raw_cmd==0x05)printf("#cmd=b\r\n");
			else if(raw_cmd==0x07)printf("#cmd=l\r\n");
		}

#if DEBUG_SERIAL
		if(dbg_ready)  //有新数据就发一次
		{
			dbg_ready = 0;
			if(++telemetry_div<10)continue;
			telemetry_div=0;
			/*每5个角度样本报告一次编码器有符号计数（约0.5秒窗口）。*/
			if(++diag_div>=5)
			{
				int enc_l,enc_r;
				diag_div=0;
				__disable_irq();
				enc_l=Encoder_Diag_Left;
				enc_r=Encoder_Diag_Right;
				Encoder_Diag_Left=0;
				Encoder_Diag_Right=0;
				__enable_irq();
				printf("#enc L=%d R=%d sum=%d\r\n",enc_l,enc_r,enc_l+enc_r);
				if(Sonar_Valid)printf("#dist=%d\r\n",Sonar_Distance_Cm);
				else printf("#dist=NA\r\n");
				Navigation_Show();
			}
			if(Bin_Mode)//App在用二进制协议，回传也得用它，否则波形控件收不到
			{
				float out[4];
				out[0]=dbg_Pitch;
				out[1]=dbg_Gyroy;
				out[2]=(float)dbg_Velocity_out;
				out[3]=(float)dbg_MOTO1;
				Bin_Send(out,4);
			}
			else
			{
				//角度,角速度Y,直立环,速度环,转向环,左PWM,右PWM
				BT_SendDebugCsv();
			}
			bt_tx_rows++;
			}
			/*显示串口计数，不占用角度/距离显示区域*/
			if(Bt_Rx!=oled_rx_seen || bt_tx_rows/10!=oled_tx_bucket || Bt_RawCmd!=oled_cmd_seen)
			{
				oled_rx_seen=Bt_Rx;
				oled_tx_bucket=bt_tx_rows/10;
				oled_cmd_seen=Bt_RawCmd;
				OLED_ShowNumber(42,0,Bt_Rx,6,12);
				OLED_ShowNumber(42,2,bt_tx_rows,6,12);
				OLED_ShowNumber(42,4,Bt_Last,3,12);
				OLED_ShowNumber(42,6,Bt_RawCmd,3,12);
			}
#else
		length = Sonar_Valid?Sonar_Distance_Cm:0;
		OLED_Float(3,70,Pitch,1);
		OLED_Float(4,64,length,1);
		OLED_Num3(8,5,(int)((Encoder_Left+Encoder_Right)*2.38));
		OLED_ShowString(0,6,"rx:",12);//蓝牙收到的字节数，自检链路用
		OLED_ShowNumber(30,6,Bt_Rx,6,12);
		OLED_ShowString(0,7,"last:",12);//最后收到的字节值，自检波特率用
		OLED_ShowNumber(42,7,Bt_Last,3,12);
#endif
	} 	
}

//void TIM3_IRQHandler(void)
//{
//		if (TIM_GetITStatus(TIM3,TIM_IT_Update)!= RESET) //检查是否发生TIM3中断
//		{
//			TIM_ClearITPendingBit(TIM3, TIM_IT_Update );   //清楚中断更新标志
//			overcount++;
//		}
//}
