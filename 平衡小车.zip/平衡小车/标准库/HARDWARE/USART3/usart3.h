﻿#ifndef __USART3_H
#define __USART3_H

#include "sys.h" 



#define CMD_MAX 24			//文本命令行最长字节数

extern char Cmd_Buf[CMD_MAX];		//正在攒的一行
extern char Cmd_Line[CMD_MAX];		//攒好的行，等主循环取
extern u8 Cmd_Len;					//当前攒了几个字节
extern volatile u8 Cmd_Ready;		//有一行攒好了

/*蓝牙调试器(ValuePack)二进制包：0xA5|数据|校验|0x5A*/
#define BIN_FLOATS 11						//App发送包里的float个数，顺序见control.c
#define BIN_MAX    (1+BIN_FLOATS*4+2)		//整包长度 = 包头+数据+校验+包尾
#define BIN_OUT    4						//本机回传的float个数

extern u8 Bin_Buf[BIN_MAX];		//中断收到的原始包
extern u8 Bin_Line[BIN_MAX];	//抄给主循环解析的一份
extern u8 Bin_Len;					//当前收到第几个字节
extern volatile u8 Bin_Ready;	//收到一个完整包
extern u8 Bin_Mode;				//收到过二进制包就置1，回传改用它
extern volatile u32 Bt_Rx;		//开机以来收到的字节总数，自检链路用
extern volatile u8  Bt_Last;	//最后收到的一个字节，自检波特率用
extern volatile u8  Bt_RawCmd;	//最近收到的HEX遥控命令
extern volatile u8  Bt_RawCmd_Ready;//HEX遥控命令待主循环回执

void Bin_Send(float *v,u8 n);//按ValuePack格式回传一包

void USART3_Send_Data(char data);	//发一个字节
void USART3_Send_String(char *String);
void uart3_init(u32 bound);					//串口1初始化函数
void USART3_IRQHandler(void);     	//串口1中断服务程序
#endif
