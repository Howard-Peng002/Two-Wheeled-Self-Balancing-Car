﻿#include "usart3.h"	  
#include "control.h"
void uart3_init(u32 bound)
{
	//GPIO端口设置
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);//时钟GPIOB、USART3
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	
	//USART1_TX   PB10
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	//USART1_RX	  PB11
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);  
	//USART 初始化设置
	USART_InitStructure.USART_BaudRate = bound;//一般设置为9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART3, &USART_InitStructure);
	
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);//开启中断
	USART_Cmd(USART3, ENABLE);                    //使能串口 
}

u8 Fore,Back,Left,Right;

/*调参命令缓冲：中断里只收字节，解析放主循环*/
/*控制环中断优先级0、串口是2，串口中断会被控制环打断，所以这里不能做耗时的事*/
char Cmd_Buf[CMD_MAX];	//正在攒的一行
char Cmd_Line[CMD_MAX];	//抄给主循环解析的一行
u8 Cmd_Len=0;					//当前攒了几个字节
volatile u8 Cmd_Ready=0;//有一行攒好了

u8 Bin_Buf[BIN_MAX];		//中断收到的原始包
u8 Bin_Line[BIN_MAX];		//抄给主循环解析的一份
u8 Bin_Len=0;						//当前收到第几个字节
volatile u8 Bin_Ready=0;//收到一个完整包
u8 Bin_Mode=0;					//收到过二进制包就置1，回传改用它
volatile u32 Bt_Rx=0;		//开机以来收到的字节总数，自检链路用
volatile u8  Bt_Last=0;		//最后收到的一个字节，自检波特率用
volatile u8  Bt_RawCmd=0;		//最近收到的HEX遥控命令
volatile u8  Bt_RawCmd_Ready=0;	//HEX遥控命令待主循环回执

void USART3_IRQHandler(void)
{
	int Bluetooth_data;
	if(USART_GetITStatus(USART3,USART_IT_RXNE)!=RESET)//接收中断标志位拉高
	{
		Bluetooth_data=USART_ReceiveData(USART3);//保存接收的数据
		Bt_Rx++;								//自检：蓝牙一共进来几个字节
		Bt_Last=(u8)Bluetooth_data;	//自检：最后一个字节

		//1.蓝牙调试器的二进制包：定长BIN_MAX字节，0x5A结尾
		if(Bin_Len)
		{
			Bin_Buf[Bin_Len++]=(u8)Bluetooth_data;
			if(Bin_Len>=BIN_MAX)
			{
				Bin_Len=0;
				if(Bluetooth_data==0x5A)Bin_Ready=1,Bin_Mode=1;
			}
			return;
		}
		if(Bluetooth_data==0xA5){Bin_Buf[Bin_Len++]=0xA5;return;}//包头，开始收包

		//2.文本命令：可打印字符攒一行，回车结束
		if(Bluetooth_data>=0x20&&Bluetooth_data<0x7F)
		{
			if(Cmd_Len<CMD_MAX-1)Cmd_Buf[Cmd_Len++]=Bluetooth_data;
		}
		else if(Bluetooth_data=='\r'||Bluetooth_data=='\n')//回车换行-->这一行结束，交给主循环
		{
			if(Cmd_Len)
			{
				Cmd_Buf[Cmd_Len]=0;
				if(!Cmd_Ready){strcpy(Cmd_Line,Cmd_Buf);Cmd_Ready=1;}
				Cmd_Len=0;
			}
		}
		//3.不可打印字符-->单字节遥控指令
		else
		{
			if(Bluetooth_data==0x00||Bluetooth_data==0x01||Bluetooth_data==0x03||Bluetooth_data==0x05||Bluetooth_data==0x07)
			{
				Bt_RawCmd=(u8)Bluetooth_data;
				Bt_RawCmd_Ready=1;
			}
			if(Bluetooth_data==0x00)Navigation_Stop();//刹车，自动模式也必须可停
			else if(Nav_Mode==0 && Bluetooth_data==0x01)Fore=1,Back=0,Left=0,Right=0;//前
			else if(Nav_Mode==0 && Bluetooth_data==0x05)Fore=0,Back=1,Left=0,Right=0;//后
			else if(Nav_Mode==0 && Bluetooth_data==0x03)Fore=0,Back=0,Left=0,Right=1;//右
			else if(Nav_Mode==0 && Bluetooth_data==0x07)Fore=0,Back=0,Left=1,Right=0;//左
			else													Fore=0,Back=0,Left=0,Right=0;//刹
		}
	}
}

/*按蓝牙调试器(ValuePack)格式回传一包*/
/*入口：float数组、个数（最多4个）*/
void Bin_Send(float *v,u8 n)
{
	u8 buf[1+4*4+2];
	u8 i,j,sum=0;
	u8 *p;
	float f;

	if(n>4)n=4;
	buf[0]=0xA5;
	for(i=0;i<n;i++)
	{
		f=v[i];
		p=(u8*)&f;								//float按小端铺开
		for(j=0;j<4;j++)buf[1+i*4+j]=p[j];
	}
	for(i=1;i<1+n*4;i++)sum+=buf[i];//校验和只算数据，不含包头
	buf[1+n*4]=sum;
	buf[1+n*4+1]=0x5A;

	for(i=0;i<1+n*4+2;i++)USART3_Send_Data(buf[i]);
}

//一个
void USART3_Send_Data(char data)
{
	USART_SendData(USART3,data);
	while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=1);
}

//一串
void USART3_Send_String(char *String)
{
	u16 len,j;
	
	len=strlen(String);
	for(j=0;j<len;j++)
	{
		USART3_Send_Data(*String++);
	}
}





