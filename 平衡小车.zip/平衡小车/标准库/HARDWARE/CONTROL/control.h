#ifndef  _CONTROL_H
#define  _CONTROL_H

#include "sys.h" 
extern volatile u8 Motion_Reset_Requested;
extern volatile u8 Nav_Mode,Nav_Run,Nav_Hazard;
void Navigation_Task(void);
void Navigation_Stop(void);
void Navigation_Show(void);





int Vertical(float Med,float Angle,float gyro_Y);
int Velocity(int Target,int encoder_left,int encoder_right);
int Turn(int gyro_Z,int RC);
void EXTI9_5_IRQHandler(void);

void PID_Show(void);			//回读全部参数
void BT_Cmd(char *s);			//解析一行蓝牙命令（遥控+调参）
float Clip(float v,float lo,float hi);//按量程钳位
u8 Bin_Apply(void);				//解一包蓝牙调试器的数据，返回0=校验没过
#endif

