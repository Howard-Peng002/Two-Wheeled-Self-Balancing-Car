#include "control.h"

float Med_Angle=-3.5;		//机械中值
float Target_Speed=0;	//期望速度（俯仰）
float Turn_Speed=0;		//期望速度（偏航）

float 
	 // Vertical_Kp=-400,//直立环KP、KD (KP 0~1000 KD 0~1)
	 // Vertical_Kd=-1.92;//-1.7;
     Vertical_Kp=-521,
	 Vertical_Kd=-1.95;
float
	// Velocity_Kp=0.44,//速度环KP、KI
	// Velocity_Ki=0.0022;//0.01;
	Velocity_Kp=0.313,//速度环KP、KI
	Velocity_Ki=0.0054;
float 
	Turn_Kd=0.47,//转向环KP、KD
	Turn_Kp=68;
float Turn_Kd_Set=0.47;//App设定值；每次控制中断保持转向阻尼
extern int length;
#define SPEED_Y 35   //蓝牙前后速度上限
#define SPEED_Z 40   //遥控转向限速，避免单次指令产生过大差速
#define AUTO_SPEED 20 //自动模式速度上限
#define AUTO_RAMP_TICKS 4 //自动前进每4个控制周期增加1，避免起步过猛
#define AUTO_TURN 12
#define SONAR_STOP_CM 30 //前方30cm开始停止；实车制动距离须单独验证
#define SONAR_CLEAR_CM 40 //保持10cm迟滞，避免阈值附近反复启停
#define SONAR_CLEAR_SAMPLES 3 //近墙后需连续三次远距离读数才能恢复前进
#define MANUAL_STOP_CM 40 //蓝牙控制连续近距样本触发停车；自动仍用30cm
#define MANUAL_EMERGENCY_CM 20 //极近距离单次即停，避免确认等待造成碰撞
#define MANUAL_STOP_SAMPLES 2 //两次连续有效原始测距<=40cm
#define MANUAL_CLEAR_CM 55 //障碍移开后连续确认；不会自动恢复前进
#define MANUAL_SLOW_CM 80 //进入此距离后逐步降低前进目标速度
#define MANUAL_NEAR_SPEED 12 //接近停车线时的最高前进目标速度
#define MANUAL_CLEAR_SAMPLES 5
#define VELOCITY_ANGLE_MAX 8.0f //速度环对直立目标角的最大修正（度）
#define BRAKE_FILTER_A 0.15f //停止后更快使用实测轮速；仍保持原8度倾角限幅
#define BRAKE_STILL_COUNTS 3 //两轮合计编码器每控制周期接近零的阈值
#define BRAKE_STILL_SAMPLES 10 //确认轮速持续接近零后才退出制动阶段
#define FORWARD_BRAKE_ANGLE_MAX 10.0f //仅前进停止后的短时制动倾角上限
#define FORWARD_BRAKE_TICKS 50 //最长约0.5秒，避免长期反向顶电机
#define FORWARD_BRAKE_PWM_MAX 6000 //制动期间PWM低于原7200硬限幅
#define AUTO_TILT_ABORT_DEG 12.0f //自动行驶倾斜过大则停止推进，仍由直立环恢复


int Vertical_out,Velocity_out,Turn_out;//直立环&速度环&转向环 的输出变量

/*串口调试变量*/
/*中断里只赋值，printf放主循环*/
float dbg_Pitch=0, dbg_Gyroy=0;        //车身角度、角速度Y
int   dbg_Vertical_out=0, dbg_Velocity_out=0, dbg_Turn_out=0;//三环输出
int   dbg_MOTO1=0, dbg_MOTO2=0;        //左右电机PWM
volatile u8 dbg_ready=0;               //新数据标志

int Encoder_S=0;//速度环积分量（rst命令清零）
static int Encoder_Filter_Last=0;
static u8 Brake_Active=0,Brake_Still_Samples=0;
static u8 Forward_Brake_Tick=0,Forward_Brake_Boost=0;
static volatile u8 Auto_Ramp_Ticks=0;
volatile u8 Motion_Reset_Requested=0;//停止命令由串口置位，在控制中断中统一清状态
extern volatile u16 Sonar_Distance_Cm;
extern volatile u16 Sonar_Raw_Cm;
extern volatile u8 Sonar_Valid,Sonar_Sample_Seq;
volatile u8 Nav_Mode=2,Nav_Run=0,Nav_Hazard=1; //0=手动，1=自动，2=关闭
static volatile u8 Manual_Hazard=1,Manual_Speed_Limit=0;
enum{NAV_IDLE,NAV_FORWARD,NAV_BRAKE,NAV_TURN,NAV_BLOCKED,NAV_FAULT};
static volatile u8 Nav_State=NAV_IDLE;
static u8 nav_seen=0,nav_still=0,nav_clear=0,nav_turn_ticks=0,nav_turn_right=0;
static u8 nav_far_samples=0;
static u8 manual_clear_samples=0,manual_near_samples=0;

void Navigation_Stop(void)
{
	Nav_Run=0;
	Nav_State=NAV_IDLE;
	Fore=Back=Left=Right=0;
	Auto_Ramp_Ticks=0;
	Motion_Reset_Requested=1;
}

void Navigation_Task(void)
{
	u8 seq=Sonar_Sample_Seq;
	u16 near_cm;
	int wheel;
	if(seq==nav_seen)return;
	nav_seen=seq;
	if(!Sonar_Valid || Sonar_Raw_Cm<=SONAR_STOP_CM)
	{
		Nav_Hazard=1;
		nav_far_samples=0;
	}
	else if(Sonar_Raw_Cm>=SONAR_CLEAR_CM && Sonar_Distance_Cm>=SONAR_CLEAR_CM)
	{
		if(nav_far_samples<SONAR_CLEAR_SAMPLES)nav_far_samples++;
		if(nav_far_samples>=SONAR_CLEAR_SAMPLES)Nav_Hazard=0;
	}
	else nav_far_samples=0;
	/* The nearer raw/filtered distance limits speed; only consecutive raw near
	   samples stop the car. Both must be far before a stop can be cleared. */
	near_cm=Sonar_Raw_Cm<Sonar_Distance_Cm?Sonar_Raw_Cm:Sonar_Distance_Cm;
	if(Sonar_Valid && Sonar_Raw_Cm<=MANUAL_STOP_CM)
	{
		if(manual_near_samples<MANUAL_STOP_SAMPLES)manual_near_samples++;
	}
	else manual_near_samples=0;
	if(!Sonar_Valid || Sonar_Raw_Cm<=MANUAL_EMERGENCY_CM ||
	   manual_near_samples>=MANUAL_STOP_SAMPLES)
	{
		Manual_Hazard=1;
		manual_clear_samples=0;
	}
	else if(Sonar_Raw_Cm>=MANUAL_CLEAR_CM && Sonar_Distance_Cm>=MANUAL_CLEAR_CM)
	{
		if(manual_clear_samples<MANUAL_CLEAR_SAMPLES)manual_clear_samples++;
		if(manual_clear_samples>=MANUAL_CLEAR_SAMPLES)Manual_Hazard=0;
	}
	else manual_clear_samples=0;
	if(Manual_Hazard)Manual_Speed_Limit=0;
	else if(near_cm<=MANUAL_STOP_CM)Manual_Speed_Limit=MANUAL_NEAR_SPEED;
	else if(near_cm>=MANUAL_SLOW_CM)Manual_Speed_Limit=SPEED_Y;
	else Manual_Speed_Limit=MANUAL_NEAR_SPEED+
		(u8)(((u32)(near_cm-MANUAL_STOP_CM)*(SPEED_Y-MANUAL_NEAR_SPEED))/
		     (MANUAL_SLOW_CM-MANUAL_STOP_CM));
	if(Nav_Mode==0)
	{
		/* Clear the latched forward command. A later far echo must not make
		   the car restart toward the wall without another button press. */
		if(Manual_Hazard && Fore)Navigation_Stop();
		return;
	}
	if(!Nav_Run)return;
	if(!Sonar_Valid)
	{
		Nav_Run=0;
		Nav_State=NAV_BLOCKED;
		Motion_Reset_Requested=1;
		return;
	}
	wheel=Encoder_Left+Encoder_Right;
	if(wheel<0)wheel=-wheel;
	if(Nav_State==NAV_FORWARD && Nav_Hazard)
	{
		Nav_State=NAV_BRAKE;
		nav_still=0;
		Motion_Reset_Requested=1;
	}
	else if(Nav_State==NAV_BRAKE)
	{
		if(wheel<=6)nav_still++;else nav_still=0;
		if(nav_still>=2 && Sonar_Valid)
		{
			Nav_State=NAV_TURN;
			nav_turn_right=!nav_turn_right;
			nav_turn_ticks=nav_clear=0;
		}
	}
	else if(Nav_State==NAV_TURN)
	{
		if(nav_turn_ticks<255)nav_turn_ticks++;
		if(Sonar_Valid && !Nav_Hazard && Sonar_Distance_Cm>=SONAR_CLEAR_CM)nav_clear++;
		else nav_clear=0;
		if(nav_turn_ticks>=5 && nav_clear>=2)Nav_State=NAV_FORWARD;
		else if(nav_turn_ticks>=25)
		{
			Nav_Run=0;
			Nav_State=NAV_BLOCKED;
			Motion_Reset_Requested=1;
		}
	}
}

void Navigation_Show(void)
{
printf("#mode=%s state=%s t=%d e=%d mh=%d\r\n",Nav_Mode==2?"off":Nav_Mode==1?"auto":"manual",
	       Nav_State==NAV_FORWARD?"forward":Nav_State==NAV_BRAKE?"brake":
	       Nav_State==NAV_TURN?"turn":Nav_State==NAV_BLOCKED?"blocked":
	       Nav_State==NAV_FAULT?"fault":"stopped",
	       (int)Target_Speed,Encoder_Left+Encoder_Right,Manual_Hazard);
}
volatile int Encoder_Diag_Left=0,Encoder_Diag_Right=0;//诊断窗口内编码器有符号计数

int Vertical(float Med,float Angle,float gyro_Y);//函数声明
int Velocity(int Target,int encoder_left,int encoder_right);
int Turn(int gyro_Z,int RC);

void EXTI9_5_IRQHandler(void)
{
	int PWM_out;
	if(EXTI_GetITStatus(EXTI_Line5)!=0)//一级判定
	{
		if(PBin(5)==0)//二级判定
		{
			EXTI_ClearITPendingBit(EXTI_Line5);//清除中断标志位
			
			//1、采集编码器数据&MPU6050角度信息。
			// 实测两轮向前转时原读数均为负；速度目标前进为正，故两路一起翻转。
			Encoder_Left=Read_Speed(2);
			Encoder_Right=-Read_Speed(4);
			Encoder_Diag_Left+=Encoder_Left;
			Encoder_Diag_Right+=Encoder_Right;
			
			mpu_dmp_get_data(&Roll,&Pitch,&Yaw);			//角度
			MPU_Get_Gyroscope(&gyroy,&gyrox,&gyroz);	//陀螺仪
			MPU_Get_Accelerometer(&aacx,&aacy,&aacz);	//加速度
			if(Nav_Mode==1 && Nav_Run && Nav_State==NAV_FORWARD &&
			   (Pitch-Med_Angle>AUTO_TILT_ABORT_DEG || Pitch-Med_Angle<(-AUTO_TILT_ABORT_DEG)))
			{
				Nav_Run=0;
				Nav_State=NAV_FAULT;
				Auto_Ramp_Ticks=0;
				Motion_Reset_Requested=1;
			}
			if(Motion_Reset_Requested)
			{
				Brake_Active=1;
				Brake_Still_Samples=0;
				Forward_Brake_Tick=0;
			}
			if(stop)Brake_Active=0;
			if(Motion_Reset_Requested || stop)
			{
				Target_Speed=0;
				Turn_Speed=0;
				Encoder_S=0;
				Encoder_Filter_Last=0;
				Motion_Reset_Requested=0;
				if(stop)Fore=0,Back=0,Left=0,Right=0,stop=0;
			}

			// 蓝牙遥控
			/*********************************************************************************************/
			/*前后*/
			if(Nav_Mode==0 && !Fore && !Back)Target_Speed=0;
			// 前倾时 Pitch 变负；前进应先给出负的目标倾角。
			// 速度误差是编码器读数减目标速度，因此前进目标取正、后退取负。
			if(Nav_Mode==0)
			{
				if(Fore && !Manual_Hazard)
				{
					if(Target_Speed<Manual_Speed_Limit)Target_Speed++;
					if(Target_Speed>Manual_Speed_Limit)Target_Speed=Manual_Speed_Limit;
				}
				if(Back)Target_Speed--;
				if((Fore && !Manual_Hazard) || Back)Brake_Active=0;
				if(Fore && Manual_Hazard)Target_Speed=0;
			}
			else if(Nav_Run && Nav_State==NAV_FORWARD && !Nav_Hazard)
			{
				if(++Auto_Ramp_Ticks>=AUTO_RAMP_TICKS)
				{
					Auto_Ramp_Ticks=0;
					if(Target_Speed<AUTO_SPEED)Target_Speed++;
				}
				Brake_Active=0;
			}
			else Target_Speed=0,Auto_Ramp_Ticks=0;
			Target_Speed=Target_Speed>SPEED_Y?SPEED_Y:(Target_Speed<-SPEED_Y?(-SPEED_Y):Target_Speed);//限幅
			if(Nav_Mode && Target_Speed>AUTO_SPEED)Target_Speed=AUTO_SPEED;
			
			/*左右*/
			if(Nav_Mode==0 && !Left && !Right)Turn_Speed=0;
			if(Nav_Mode==0)
			{
				if(Left==1)Turn_Speed-=4;
				if(Right==1)Turn_Speed+=4;
			}
			else if(Nav_Run && Nav_State==NAV_TURN)
				Turn_Speed=nav_turn_right?AUTO_TURN:-AUTO_TURN;
			else Turn_Speed=0;
			Turn_Speed=Turn_Speed>SPEED_Z?SPEED_Z:(Turn_Speed<-SPEED_Z?(-SPEED_Z):Turn_Speed);//限幅( (20*100) * 100   )
			
			/*转向时仍保留角速度阻尼，避免只靠差速指令冲击车身。*/
			Turn_Kd=Turn_Kd_Set;
			/*********************************************************************************************/
			
			//2、将数据压入闭环控制中，计算出控制输出量。
			Velocity_out=Velocity(Target_Speed,Encoder_Left,Encoder_Right);	//速度环
			Vertical_out=Vertical(Velocity_out+Med_Angle,Pitch,gyroy);			//直立环
			Turn_out=Turn(gyroz,Turn_Speed);																//转向环
			
			PWM_out=Vertical_out;//最终输出
			//3、把控制输出量加载到电机上，完成最终的的控制。
			MOTO1=PWM_out-Turn_out;//左电机
			MOTO2=PWM_out+Turn_out;//右电机
			Limit(&MOTO1,&MOTO2);	 //PWM限幅			
			if(Forward_Brake_Boost)
			{
				if(MOTO1>FORWARD_BRAKE_PWM_MAX)MOTO1=FORWARD_BRAKE_PWM_MAX;
				if(MOTO1<(-FORWARD_BRAKE_PWM_MAX))MOTO1=-FORWARD_BRAKE_PWM_MAX;
				if(MOTO2>FORWARD_BRAKE_PWM_MAX)MOTO2=FORWARD_BRAKE_PWM_MAX;
				if(MOTO2<(-FORWARD_BRAKE_PWM_MAX))MOTO2=-FORWARD_BRAKE_PWM_MAX;
			}
			Load(MOTO1,MOTO2);		 //加载到电机上。
			
			//4、调试快照，只赋值不打印
			dbg_Pitch        = Pitch;
			dbg_Gyroy        = gyroy;
			dbg_Vertical_out = Vertical_out;
			dbg_Velocity_out = Velocity_out;
			dbg_Turn_out     = Turn_out;
			dbg_MOTO1        = MOTO1;
			dbg_MOTO2        = MOTO2;
			dbg_ready        = 1;

			Stop(&Med_Angle,&Pitch);//安全检测
			if(stop)
			{
				Nav_Run=0;
				Nav_State=NAV_FAULT;
				Fore=Back=Left=Right=0;
			}
			
		}
	}
}


/*********************
直立环PD控制器：Kp*Ek+Kd*Ek_D

入口：期望角度、真实角度、真实角速度
出口：直立环输出
*********************/
int Vertical(float Med,float Angle,float gyro_Y)
{
	int PWM_out;
	
	PWM_out=Vertical_Kp*(Angle-Med)+Vertical_Kd*(gyro_Y-0);
	return PWM_out;
}


/*********************
速度环PI：Kp*Ek+Ki*Ek_S
*********************/
int Velocity(int Target,int encoder_left,int encoder_right)
{
	int Encoder_Err,EnC_Err_Lowout;
	float output,trial;
	float angle_max=VELOCITY_ANGLE_MAX;
	float a=0.7;
	int speed=encoder_left+encoder_right;
	Forward_Brake_Boost=0;
	if(Brake_Active)
	{
		a=BRAKE_FILTER_A;
		if(Nav_Mode==0 && Target==0 && speed>8 && Forward_Brake_Tick<FORWARD_BRAKE_TICKS)
		{
			Forward_Brake_Boost=1;
			angle_max=(Forward_Brake_Tick<FORWARD_BRAKE_TICKS/2)?
			          FORWARD_BRAKE_ANGLE_MAX:(FORWARD_BRAKE_ANGLE_MAX-1.0f);
		}
		if(Forward_Brake_Tick<FORWARD_BRAKE_TICKS)Forward_Brake_Tick++;
		if(speed>=-BRAKE_STILL_COUNTS && speed<=BRAKE_STILL_COUNTS)
		{
			if(++Brake_Still_Samples>=BRAKE_STILL_SAMPLES)
			{
				Brake_Active=0;
				Brake_Still_Samples=0;
			}
		}
		else Brake_Still_Samples=0;
	}
	
	//1.计算速度偏差
	Encoder_Err=(speed-Target);//舍去误差--我的理解：能够让速度为"0"的角度，就是机械中值。
	//2.对速度偏差进行低通滤波
	//low_out=(1-a)*Ek+a*low_out_last;
	EnC_Err_Lowout=(1-a)*Encoder_Err+a*Encoder_Filter_Last;
	Encoder_Filter_Last=EnC_Err_Lowout;
	// 输出饱和时不再向同一方向积分，防止遥控后目标角长期偏离机械中值。
	if(Velocity_Ki<=0)Encoder_S=0;
	else
	{
		trial=Velocity_Kp*EnC_Err_Lowout+Velocity_Ki*(Encoder_S+EnC_Err_Lowout);
		if(!((trial>angle_max && EnC_Err_Lowout>0) ||
		     (trial<(-VELOCITY_ANGLE_MAX) && EnC_Err_Lowout<0)))
			Encoder_S+=EnC_Err_Lowout;
		Encoder_S=Encoder_S>3000?3000:(Encoder_S<(-3000)?(-3000):Encoder_S);
	}
	output=Velocity_Kp*EnC_Err_Lowout+Velocity_Ki*Encoder_S;
	if(output>angle_max)output=angle_max;
	if(output<(-VELOCITY_ANGLE_MAX))output=-VELOCITY_ANGLE_MAX;
	return (int)output;
}



/*********************
转向环：系数*Z轴角速度+系数*遥控数据
*********************/
int Turn(int gyro_Z,int RC)
{
	int PWM_out;
	//这不是一个严格的PD控制器，Kd针对的是转向的约束，但Kp针对的是遥控的转向。
	PWM_out=Turn_Kd*gyro_Z + Turn_Kp*RC;
	return PWM_out;
}


/*********************
回读全部参数，给手机端确认用
*********************/
static void Print_Param(float v,int scale,int digits)
{
	int n=(int)(((v<0)?-v:v)*scale+0.5f);
	if(v<0)printf("-");
	if(digits==4)printf("%d.%04d",n/scale,n%scale);
	else printf("%d.%02d",n/scale,n%scale);
}

void PID_Show(void)
{
	printf("#vk=");Print_Param(Vertical_Kp,100,2);
	printf(" vd=");Print_Param(Vertical_Kd,100,2);
	printf(" vp=");Print_Param(Velocity_Kp,10000,4);
	printf(" vi=");Print_Param(Velocity_Ki,10000,4);
	printf(" td=");Print_Param(Turn_Kd_Set,100,2);
	printf(" tp=");Print_Param(Turn_Kp,100,2);
	printf(" ma=");Print_Param(Med_Angle,100,2);
	printf("\r\n");
}


/*********************
蓝牙调试器发送包里的float顺序，和App里添加的变量一一对应
顺序对不上PID就会收到乱七八糟的值，所以下面每个都按量程钳位
*********************/
enum{B_FWD,B_BACK,B_LEFT,B_RIGHT,B_VK,B_VD,B_VP,B_VI,B_TD,B_TP,B_MA};

/*按量程钳位*/
float Clip(float v,float lo,float hi)
{
	if(v<lo)return lo;
	if(v>hi)return hi;
	return v;
}

/*取包里第i个float：按字节拼，不能强转指针，非对齐访问在Cortex-M3上会硬件异常*/
static float Bin_Float(u8 i)
{
	float f;
	u8 *p=(u8*)&f;
	p[0]=Bin_Line[1+i*4+0];
	p[1]=Bin_Line[1+i*4+1];
	p[2]=Bin_Line[1+i*4+2];
	p[3]=Bin_Line[1+i*4+3];
	return f;
}

/*********************
解一包蓝牙调试器的数据，写进PID参数
入口：Bin_Line里已经放好一整包
出口：1=校验通过并已写入，0=校验没过、原参数不动
量程按参考值定：直立环Kp 0~1000、Kd 0~10，速度环Kp 0~1
*********************/
u8 Bin_Apply(void)
{
	u8 i,sum=0;

	if(Bin_Line[BIN_MAX-1]!=0x5A)return 0;//包尾不对
	for(i=1;i<BIN_MAX-2;i++)sum+=Bin_Line[i];
	//校验和算数据字节；有的资料把包头也算进去，两种都认
	if(Bin_Line[BIN_MAX-2]!=sum&&Bin_Line[BIN_MAX-2]!=(u8)(sum+0xA5))return 0;

	if(Nav_Mode==0)
	{
		Fore =(Bin_Float(B_FWD) >0.5f);
		Back =(Bin_Float(B_BACK)>0.5f);
		Left =(Bin_Float(B_LEFT)>0.5f);
		Right=(Bin_Float(B_RIGHT)>0.5f);
	}

	Vertical_Kp=Clip(Bin_Float(B_VK),-1000,0);//本车角度取负，所以量程是-1000~0
	Vertical_Kd=Clip(Bin_Float(B_VD),-10,0);
	Velocity_Kp=Clip(Bin_Float(B_VP),0,1);
	Velocity_Ki=Clip(Bin_Float(B_VI),0,0.05);
	Turn_Kd_Set=Clip(Bin_Float(B_TD),0,2);
	Turn_Kp    =Clip(Bin_Float(B_TP),0,100);
	Med_Angle  =Clip(Bin_Float(B_MA),-20,20);
	return 1;
}


/*********************
蓝牙命令，一次解析一行
入口：一行命令(已去掉回车换行)，如 "vk=-340"、"f"、"show"
调参命令：vk/vd=直立环KP、KD，vp/vi=速度环KP、KI，td/tp=转向环KD、KP，ma=机械中值
遥控命令：f前、b后、l左、r右、s刹，作用同原来的单字节遥控指令
其它：rst清积分、show回读、raw打印上一包二进制数据、csv回传改回文本
*********************/
void BT_Cmd(char *s)
{
	if(!strcmp(s,"ping")){printf("#pong\r\n");return;}
	if(!strcmp(s,"mode?")){Navigation_Show();return;}
	if(!strcmp(s,"mode=off"))
	{
		Navigation_Stop();Nav_Mode=2;Navigation_Show();return;
	}
	if(!strcmp(s,"mode=manual"))
	{
		Navigation_Stop();Nav_Mode=0;Navigation_Show();return;
	}
	if(!strcmp(s,"mode=auto"))
	{
		Navigation_Stop();Nav_Mode=1;
		if(Sonar_Valid && !Nav_Hazard && Sonar_Distance_Cm>=SONAR_CLEAR_CM)
		{
			Nav_State=NAV_FORWARD;
			Nav_Run=1;
		}
		else printf("#err auto needs clear sonar\r\n");
		Navigation_Show();return;
	}
	if(!strcmp(s,"auto=start"))
	{
		if(Nav_Mode!=1 || !Sonar_Valid || Nav_Hazard || Sonar_Distance_Cm<SONAR_CLEAR_CM)
		{printf("#err auto needs clear sonar\r\n");return;}
		Navigation_Stop();Nav_State=NAV_FORWARD;Nav_Run=1;
		Navigation_Show();return;
	}
	if(!strcmp(s,"auto=stop")){Navigation_Stop();Navigation_Show();return;}
	if(Nav_Mode==1 && (!strcmp(s,"f")||!strcmp(s,"b")||!strcmp(s,"l")||!strcmp(s,"r")))
	{printf("#err manual command in auto mode\r\n");return;}
	//1.遥控命令：只改标志位，不回读，免得占蓝牙带宽拖慢操控
	if     (!strcmp(s,"f")){Fore=1,Back=0;printf("#cmd=f\r\n");return;}		//前进
	else if(!strcmp(s,"b")){Fore=0,Back=1;printf("#cmd=b\r\n");return;}		//后退
	else if(!strcmp(s,"l")){Left=1,Right=0;printf("#cmd=l\r\n");return;}		//左转
	else if(!strcmp(s,"r")){Left=0,Right=1;printf("#cmd=r\r\n");return;}		//右转
	else if(!strcmp(s,"s")){Navigation_Stop();printf("#cmd=s\r\n");return;}	//刹车

	//2.调参命令
	if     (!strncmp(s,"vk=",3))Vertical_Kp=atof(s+3);
	else if(!strncmp(s,"vd=",3))Vertical_Kd=atof(s+3);
	else if(!strncmp(s,"vp=",3))Velocity_Kp=atof(s+3);
	else if(!strncmp(s,"vi=",3))Velocity_Ki=atof(s+3);
	else if(!strncmp(s,"td=",3))Turn_Kd_Set=Clip(atof(s+3),0,2);
	else if(!strncmp(s,"tp=",3))Turn_Kp=atof(s+3);
	else if(!strncmp(s,"ma=",3))Med_Angle=atof(s+3);
	else if(!strcmp(s,"rst"))   Encoder_S=0;	//清速度环积分
	else if(!strcmp(s,"show"));					//只回读
	else if(!strcmp(s,"csv"))   Bin_Mode=0,Bin_Len=0,printf("#csv\r\n");
	else if(!strcmp(s,"raw"))	//把上一包二进制数据按十六进制打出来，协议对不上时用来查
	{
		u8 i;
		printf("#binmode=%d ",Bin_Mode);
		for(i=0;i<BIN_MAX;i++)printf("%02X",Bin_Line[i]);
		printf("\r\n");
	}
	else{printf("#err %s\r\n",s);return;}

	PID_Show();//回读全部参数
}

